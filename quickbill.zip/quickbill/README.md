# QuickBill — Professional Invoice Generator

A production-ready, full-stack invoice management application for freelancers and small businesses.

## Tech Stack

| Layer     | Technology                                          |
|-----------|-----------------------------------------------------|
| Frontend  | React 18, Vite, TypeScript, Tailwind CSS, shadcn/ui |
| Backend   | Node.js, Express, TypeScript (tsx)                  |
| Database  | SQLite via better-sqlite3                           |
| State     | TanStack Query (React Query)                        |
| Forms     | React Hook Form                                     |
| PDF       | jsPDF + html2canvas                                 |
| UI        | Radix UI primitives + Lucide icons                  |

## Features

- ✅ **Invoice CRUD** — Create, edit, view, delete invoices
- ✅ **Line items** — Unlimited line items with quantity × rate auto-calculation
- ✅ **Tax & Discounts** — Per-invoice tax rate, percent or fixed discounts
- ✅ **Status tracking** — Draft → Sent → Paid / Overdue / Cancelled
- ✅ **PDF Export** — High-quality PDF generation directly in the browser
- ✅ **Client management** — Full client address book with invoice history
- ✅ **Dashboard** — Revenue charts, stats, recent invoices, top clients
- ✅ **Business settings** — Logo, branding, currency, tax, payment defaults
- ✅ **Multi-currency** — USD, EUR, GBP, MAD, DZD + configurable symbols
- ✅ **Print support** — Clean print styles baked in

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Start development (server + client concurrently)
npm run dev

# Frontend: http://localhost:5173
# API:      http://localhost:3001/api
```

## Production Build

```bash
npm run build        # Builds frontend to /dist
npm start            # Serves frontend + API from Node
```

## Project Structure

```
quickbill/
├── server/                 # Express API
│   ├── index.ts            # Server entry point
│   ├── db.ts               # SQLite init & connection
│   └── routes/
│       ├── invoices.ts
│       ├── clients.ts
│       ├── settings.ts
│       └── dashboard.ts
├── src/                    # React frontend
│   ├── components/
│   │   ├── layout/         # Sidebar, Layout
│   │   └── ui/             # shadcn/ui components
│   ├── pages/
│   │   ├── Dashboard.tsx
│   │   ├── InvoiceList.tsx
│   │   ├── InvoiceEditor.tsx
│   │   ├── InvoiceView.tsx
│   │   ├── Clients.tsx
│   │   └── Settings.tsx
│   ├── lib/
│   │   ├── api.ts          # API client + TypeScript types
│   │   └── utils.ts        # Helpers: formatCurrency, formatDate…
│   └── main.tsx
├── data/                   # SQLite DB files (auto-created, gitignored)
├── vite.config.ts
├── tailwind.config.js
└── package.json
```

## Database Schema

The SQLite database is auto-initialized on first run at `./data/quickbill.db`.

Tables: `settings`, `clients`, `invoices`, `invoice_items`

## Customization

- **Colors**: Edit `tailwind.config.js` CSS variables (or use the Settings UI)
- **Fonts**: Swap Google Fonts in `index.html`
- **Currency**: Add entries to the `CURRENCIES` array in `Settings.tsx`
- **Invoice template**: Edit `InvoiceView.tsx` — the `printRef` div is what gets exported to PDF
