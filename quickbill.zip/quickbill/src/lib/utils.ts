import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatCurrency(amount: number, symbol = '$', locale = 'en-US'): string {
  return `${symbol}${new Intl.NumberFormat(locale, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount)}`
}

export function formatDate(dateStr: string): string {
  if (!dateStr) return ''
  const [year, month, day] = dateStr.split('-').map(Number)
  return new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
    .format(new Date(year, month - 1, day))
}

export function today(): string {
  return new Date().toISOString().split('T')[0]
}

export function addDays(dateStr: string, days: number): string {
  const d = new Date(dateStr)
  d.setDate(d.getDate() + days)
  return d.toISOString().split('T')[0]
}

export function statusColor(status: string): string {
  switch (status) {
    case 'paid': return 'bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200'
    case 'sent': return 'bg-blue-50 text-blue-700 ring-1 ring-blue-200'
    case 'overdue': return 'bg-red-50 text-red-600 ring-1 ring-red-200'
    case 'draft': return 'bg-gray-50 text-gray-600 ring-1 ring-gray-200'
    case 'cancelled': return 'bg-gray-50 text-gray-400 ring-1 ring-gray-200'
    default: return 'bg-gray-50 text-gray-600 ring-1 ring-gray-200'
  }
}

export function statusLabel(status: string): string {
  return status.charAt(0).toUpperCase() + status.slice(1)
}
