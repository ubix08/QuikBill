const BASE = '/api'

async function req<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    headers: { 'Content-Type': 'application/json', ...options?.headers },
    ...options,
  })
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }))
    throw new Error(err.error || `HTTP ${res.status}`)
  }
  return res.json()
}

// ── Settings ──────────────────────────────────────────────────────────────────
export const api = {
  settings: {
    get: () => req<Settings>('/settings'),
    update: (data: Partial<Settings>) => req<Settings>('/settings', { method: 'PUT', body: JSON.stringify(data) }),
  },

  // ── Dashboard ───────────────────────────────────────────────────────────────
  dashboard: {
    get: () => req<DashboardData>('/dashboard'),
  },

  // ── Clients ─────────────────────────────────────────────────────────────────
  clients: {
    list: () => req<Client[]>('/clients'),
    get: (id: number) => req<Client>(`/clients/${id}`),
    create: (data: Partial<Client>) => req<Client>('/clients', { method: 'POST', body: JSON.stringify(data) }),
    update: (id: number, data: Partial<Client>) => req<Client>(`/clients/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    delete: (id: number) => req<{ success: boolean }>(`/clients/${id}`, { method: 'DELETE' }),
  },

  // ── Invoices ─────────────────────────────────────────────────────────────────
  invoices: {
    list: (params?: { status?: string; search?: string; limit?: number; offset?: number }) => {
      const q = new URLSearchParams()
      if (params?.status) q.set('status', params.status)
      if (params?.search) q.set('search', params.search)
      if (params?.limit) q.set('limit', String(params.limit))
      if (params?.offset) q.set('offset', String(params.offset))
      return req<InvoiceListResponse>(`/invoices?${q}`)
    },
    get: (id: number) => req<Invoice>(`/invoices/${id}`),
    create: (data: Partial<Invoice>) => req<Invoice>('/invoices', { method: 'POST', body: JSON.stringify(data) }),
    update: (id: number, data: Partial<Invoice>) => req<Invoice>(`/invoices/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    updateStatus: (id: number, status: string, amount_paid?: number) =>
      req<Invoice>(`/invoices/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status, amount_paid }) }),
    delete: (id: number) => req<{ success: boolean }>(`/invoices/${id}`, { method: 'DELETE' }),
  },
}

// ── Types ────────────────────────────────────────────────────────────────────
export interface Settings {
  id: number
  business_name: string
  business_email: string
  business_phone: string
  business_address: string
  business_city: string
  business_state: string
  business_zip: string
  business_country: string
  logo_url: string
  currency: string
  currency_symbol: string
  tax_label: string
  default_tax_rate: number
  invoice_prefix: string
  next_invoice_number: number
  payment_terms: string
  payment_instructions: string
  accent_color: string
}

export interface Client {
  id: number
  name: string
  email: string
  phone: string
  company: string
  address: string
  city: string
  state: string
  zip: string
  country: string
  notes: string
  invoice_count?: number
  total_paid?: number
  total_outstanding?: number
  created_at: string
}

export interface InvoiceItem {
  id?: number
  invoice_id?: number
  description: string
  details: string
  quantity: number
  rate: number
  amount: number
  sort_order?: number
}

export interface Invoice {
  id: number
  invoice_number: string
  client_id: number | null
  client_name: string
  client_email: string
  client_company: string
  client_address: string
  client_city: string
  client_state: string
  client_zip: string
  client_country: string
  status: 'draft' | 'sent' | 'paid' | 'overdue' | 'cancelled'
  issue_date: string
  due_date: string
  subtotal: number
  tax_rate: number
  tax_amount: number
  discount_type: 'percent' | 'fixed'
  discount_value: number
  discount_amount: number
  total: number
  amount_paid: number
  notes: string
  payment_terms: string
  footer_note: string
  currency: string
  currency_symbol: string
  items: InvoiceItem[]
  created_at: string
  updated_at: string
}

export interface InvoiceListResponse {
  invoices: Invoice[]
  total: number
  limit: number
  offset: number
}

export interface DashboardData {
  stats: {
    total_invoices: number
    total_billed: number
    total_paid: number
    total_outstanding: number
    overdue_count: number
    draft_count: number
    sent_count: number
    paid_count: number
  }
  monthly: Array<{ month: string; billed: number; collected: number }>
  recent: Invoice[]
  topClients: Array<{
    client_name: string
    client_company: string
    invoice_count: number
    total_billed: number
    total_paid: number
  }>
}
