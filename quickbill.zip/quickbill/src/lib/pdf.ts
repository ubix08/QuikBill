import jsPDF from 'jspdf'
import type { Invoice, Settings } from './types'
import { formatCurrency, formatDate } from './utils'

export async function exportInvoicePDF(invoice: Invoice, settings: Settings): Promise<void> {
  const doc = new jsPDF({ unit: 'mm', format: 'a4', orientation: 'portrait' })
  const W = 210
  const margin = 18
  const colRight = W - margin
  let y = margin

  const sym = invoice.currency_symbol || settings.currency_symbol || '$'
  const accentRGB = hexToRgb(settings.accent_color || '#DC8A3C')
  const darkRGB = { r: 24, g: 24, b: 27 }

  // Helpers
  const accent = () => doc.setTextColor(accentRGB.r, accentRGB.g, accentRGB.b)
  const dark = () => doc.setTextColor(darkRGB.r, darkRGB.g, darkRGB.b)
  const muted = () => doc.setTextColor(120, 113, 108)
  const line = (x1: number, y1: number, x2: number, y2: number, r = 0, g = 0, b = 0) => {
    doc.setDrawColor(r, g, b); doc.line(x1, y1, x2, y2)
  }

  // ── Header ─────────────────────────────────────────────────────────────────
  // Accent bar top
  doc.setFillColor(accentRGB.r, accentRGB.g, accentRGB.b)
  doc.rect(0, 0, W, 1.5, 'F')

  // Business name
  y = 20
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(20)
  accent()
  doc.text(settings.business_name || 'My Business', margin, y)

  // INVOICE label
  doc.setFontSize(26)
  dark()
  doc.text('INVOICE', colRight, y, { align: 'right' })

  y += 7
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(8.5)
  muted()
  const bizLines = [
    settings.business_email,
    settings.business_phone,
    settings.business_address,
    [settings.business_city, settings.business_state, settings.business_zip].filter(Boolean).join(', '),
    settings.business_country,
  ].filter(Boolean)
  bizLines.forEach(txt => { doc.text(txt, margin, y); y += 4.5 })

  // Invoice meta right side
  const metaY = 27
  doc.setFontSize(8.5)
  muted()
  doc.text('Invoice Number', colRight - 32, metaY)
  doc.text('Issue Date', colRight - 32, metaY + 6)
  doc.text('Due Date', colRight - 32, metaY + 12)
  doc.text('Status', colRight - 32, metaY + 18)

  dark()
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(9)
  doc.text(invoice.invoice_number || '—', colRight, metaY, { align: 'right' })
  doc.setFont('helvetica', 'normal')
  doc.text(formatDate(invoice.issue_date), colRight, metaY + 6, { align: 'right' })
  doc.text(formatDate(invoice.due_date), colRight, metaY + 12, { align: 'right' })
  accent()
  doc.setFont('helvetica', 'bold')
  doc.text((invoice.status || 'draft').toUpperCase(), colRight, metaY + 18, { align: 'right' })
  dark()

  y = Math.max(y, metaY + 28) + 4

  // Divider
  doc.setDrawColor(220, 215, 210)
  doc.setLineWidth(0.3)
  doc.line(margin, y, colRight, y)
  y += 8

  // ── Bill To ────────────────────────────────────────────────────────────────
  muted()
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(7.5)
  doc.text('BILL TO', margin, y)
  y += 5
  dark()
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(10)
  doc.text(invoice.client_name || 'Client', margin, y)
  y += 5
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(8.5)
  muted()
  const clientLines = [
    invoice.client_company,
    invoice.client_email,
    invoice.client_address,
    [invoice.client_city, invoice.client_state, invoice.client_zip].filter(Boolean).join(', '),
    invoice.client_country,
  ].filter(Boolean)
  clientLines.forEach(txt => { doc.text(txt!, margin, y); y += 4.5 })
  y += 6

  // ── Items Table ────────────────────────────────────────────────────────────
  const colDesc = margin
  const colQty = 115
  const colRate = 145
  const colAmt = colRight

  // Header row
  doc.setFillColor(accentRGB.r, accentRGB.g, accentRGB.b)
  doc.rect(margin - 2, y - 5, W - 2 * margin + 4, 9, 'F')
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(8)
  doc.setTextColor(255, 255, 255)
  doc.text('DESCRIPTION', colDesc, y)
  doc.text('QTY', colQty, y, { align: 'right' })
  doc.text('RATE', colRate, y, { align: 'right' })
  doc.text('AMOUNT', colAmt, y, { align: 'right' })
  y += 7

  // Item rows
  doc.setFont('helvetica', 'normal')
  const items = invoice.items || []
  items.forEach((item, idx) => {
    if (idx % 2 === 0) {
      doc.setFillColor(250, 248, 244)
      doc.rect(margin - 2, y - 4, W - 2 * margin + 4, 8.5, 'F')
    }
    dark()
    doc.setFontSize(8.5)
    doc.text(item.description, colDesc, y, { maxWidth: 75 })
    muted()
    doc.text(String(item.quantity), colQty, y, { align: 'right' })
    doc.text(formatCurrency(item.rate, sym), colRate, y, { align: 'right' })
    dark()
    doc.text(formatCurrency(item.amount, sym), colAmt, y, { align: 'right' })
    if (item.details) {
      y += 4.5
      muted()
      doc.setFontSize(7.5)
      doc.text(item.details, colDesc, y, { maxWidth: 80 })
    }
    y += 8
  })

  y += 2
  doc.setDrawColor(220, 215, 210)
  doc.line(margin, y, colRight, y)
  y += 6

  // ── Totals ─────────────────────────────────────────────────────────────────
  const totalsX = 130
  const totalsLabel = (label: string, val: string, bold = false) => {
    muted()
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(8.5)
    doc.text(label, totalsX, y)
    if (bold) {
      dark()
      doc.setFont('helvetica', 'bold')
      doc.setFontSize(10)
    } else {
      dark()
    }
    doc.text(val, colRight, y, { align: 'right' })
    y += 6
  }

  totalsLabel('Subtotal', formatCurrency(invoice.subtotal, sym))
  if (invoice.discount_amount > 0) {
    totalsLabel(`Discount`, `−${formatCurrency(invoice.discount_amount, sym)}`)
  }
  if (invoice.tax_rate > 0) {
    totalsLabel(`${settings.tax_label || 'Tax'} (${invoice.tax_rate}%)`, formatCurrency(invoice.tax_amount, sym))
  }
  y += 2
  // Total box
  doc.setFillColor(accentRGB.r, accentRGB.g, accentRGB.b)
  doc.rect(totalsX - 4, y - 5, colRight - totalsX + 8, 10, 'F')
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(10)
  doc.setTextColor(255, 255, 255)
  doc.text('TOTAL DUE', totalsX, y)
  doc.text(formatCurrency(invoice.total, sym), colRight, y, { align: 'right' })
  y += 14

  // ── Notes & Payment ────────────────────────────────────────────────────────
  if (invoice.notes || invoice.payment_terms || settings.payment_instructions) {
    doc.setDrawColor(220, 215, 210)
    doc.line(margin, y, colRight, y)
    y += 8

    if (invoice.notes) {
      muted()
      doc.setFont('helvetica', 'bold')
      doc.setFontSize(7.5)
      doc.text('NOTES', margin, y)
      y += 4.5
      dark()
      doc.setFont('helvetica', 'normal')
      doc.setFontSize(8.5)
      const noteLines = doc.splitTextToSize(invoice.notes, 80)
      doc.text(noteLines, margin, y)
      y += noteLines.length * 4.5 + 4
    }

    if (settings.payment_instructions) {
      muted()
      doc.setFont('helvetica', 'bold')
      doc.setFontSize(7.5)
      doc.text('PAYMENT INSTRUCTIONS', margin, y)
      y += 4.5
      dark()
      doc.setFont('helvetica', 'normal')
      doc.setFontSize(8.5)
      const piLines = doc.splitTextToSize(settings.payment_instructions, 80)
      doc.text(piLines, margin, y)
    }
  }

  // ── Footer ─────────────────────────────────────────────────────────────────
  const footerY = 285
  doc.setDrawColor(accentRGB.r, accentRGB.g, accentRGB.b)
  doc.setLineWidth(0.4)
  doc.line(margin, footerY, colRight, footerY)
  muted()
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(7.5)
  doc.text(invoice.footer_note || 'Thank you for your business!', W / 2, footerY + 5, { align: 'center' })

  doc.save(`${invoice.invoice_number || 'invoice'}.pdf`)
}

function hexToRgb(hex: string): { r: number; g: number; b: number } {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex)
  return result
    ? { r: parseInt(result[1], 16), g: parseInt(result[2], 16), b: parseInt(result[3], 16) }
    : { r: 220, g: 138, b: 60 }
}
