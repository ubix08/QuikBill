export type InvoiceStatus = 'draft' | 'sent' | 'paid' | 'overdue' | 'cancelled'
export type DiscountType = 'percent' | 'fixed'

export interface InvoiceItem {
  id?: number
  invoice_id?: number
  description: string
  details?: string
  quantity: number
  rate: number
  amount: number
  sort_order?: number
}

export interface Invoice {
  id?: number
  invoice_number?: string
  client_id?: number | null
  client_name: string
  client_email?: string
  client_company?: string
  client_address?: string
  client_city?: string
  client_state?: string
  client_zip?: string
  client_country?: string
  status: InvoiceStatus
  issue_date: string
  due_date: string
  subtotal: number
  tax_rate: number
  tax_amount: number
  discount_type: DiscountType
  discount_value: number
  discount_amount: number
  total: number
  amount_paid?: number
  notes?: string
  payment_terms?: string
  footer_note?: string
  currency?: string
  currency_symbol?: string
  items: InvoiceItem[]
  created_at?: string
  updated_at?: string
}

export interface Client {
  id?: number
  name: string
  email?: string
  phone?: string
  company?: string
  address?: string
  city?: string
  state?: string
  zip?: string
  country?: string
  notes?: string
  invoice_count?: number
  total_billed?: number
  created_at?: string
}

export interface Settings {
  id: number
  business_name: string
  business_email: string
  business_phone: string
  business_address: string
  business_city: string
  business_state: string
  business_zip: string
  business_country: string
  logo_url: string
  currency: string
  currency_symbol: string
  tax_label: string
  default_tax_rate: number
  invoice_prefix: string
  next_invoice_number: number
  payment_terms: string
  payment_instructions: string
  accent_color: string
}

export interface DashboardStats {
  overview: {
    total_invoices: number
    total_billed: number
    total_paid: number
    total_outstanding: number
    total_overdue: number
    draft_count: number
    sent_count: number
    paid_count: number
    overdue_count: number
  }
  monthlyRevenue: { month: string; paid: number; billed: number }[]
  recentInvoices: Partial<Invoice>[]
  topClients: {
    client_name: string
    client_company: string
    invoice_count: number
    total_billed: number
    total_paid: number
  }[]
}
