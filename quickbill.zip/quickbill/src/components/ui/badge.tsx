import * as React from 'react'
import { cn } from '@/lib/utils'

interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: 'default' | 'secondary' | 'success' | 'warning' | 'destructive'
}

export function Badge({ className, variant = 'default', ...props }: BadgeProps) {
  return (
    <span
      className={cn(
        'status-badge',
        {
          default: 'bg-primary/10 text-primary',
          secondary: 'bg-muted text-muted-foreground',
          success: 'bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200',
          warning: 'bg-amber-50 text-amber-700 ring-1 ring-amber-200',
          destructive: 'bg-red-50 text-red-600 ring-1 ring-red-200',
        }[variant],
        className
      )}
      {...props}
    />
  )
}
