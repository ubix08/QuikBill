import { cn, STATUS_LABELS } from '@/lib/utils'
import type { InvoiceStatus } from '@/lib/types'

const colors: Record<InvoiceStatus, string> = {
  draft: 'bg-zinc-100 text-zinc-600 border-zinc-200',
  sent: 'bg-blue-50 text-blue-700 border-blue-200',
  paid: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  overdue: 'bg-red-50 text-red-700 border-red-200',
  cancelled: 'bg-zinc-100 text-zinc-400 border-zinc-200',
}

const dots: Record<InvoiceStatus, string> = {
  draft: 'bg-zinc-400',
  sent: 'bg-blue-500',
  paid: 'bg-emerald-500',
  overdue: 'bg-red-500',
  cancelled: 'bg-zinc-300',
}

interface Props {
  status: InvoiceStatus
  size?: 'sm' | 'default'
  className?: string
}

export default function StatusBadge({ status, size = 'default', className }: Props) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full border font-medium',
        size === 'sm' ? 'px-2 py-0.5 text-[11px]' : 'px-2.5 py-1 text-xs',
        colors[status],
        className,
      )}
    >
      <span className={cn('inline-block rounded-full', size === 'sm' ? 'h-1.5 w-1.5' : 'h-2 w-2', dots[status])} />
      {STATUS_LABELS[status]}
    </span>
  )
}
