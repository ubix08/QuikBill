import { NavLink, Outlet, useLocation } from 'react-router-dom'
import {
  LayoutDashboard, FileText, Users, Settings,
  Zap, PlusCircle, Menu, X,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useState } from 'react'
import { Button } from '@/components/ui/button'

const navItems = [
  { to: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/invoices', icon: FileText, label: 'Invoices' },
  { to: '/clients', icon: Users, label: 'Clients' },
  { to: '/settings', icon: Settings, label: 'Settings' },
]

export default function AppLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const location = useLocation()

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          'fixed inset-y-0 left-0 z-50 flex w-64 flex-col transition-transform duration-300 lg:static lg:translate-x-0',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full',
        )}
        style={{ background: 'hsl(var(--sidebar))' }}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 px-5 py-5 border-b border-sidebar-border">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary shrink-0">
            <Zap className="h-4 w-4 text-white" />
          </div>
          <div>
            <span className="font-display text-lg font-semibold text-sidebar-foreground tracking-tight">
              QuickBill
            </span>
            <div className="text-[10px] text-sidebar-muted font-medium uppercase tracking-widest">
              Pro Invoicing
            </div>
          </div>
          <button
            className="ml-auto lg:hidden text-sidebar-muted hover:text-sidebar-foreground"
            onClick={() => setSidebarOpen(false)}
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* New Invoice CTA */}
        <div className="px-4 py-4">
          <NavLink to="/invoices/new">
            <Button size="default" className="w-full gap-2 justify-start font-semibold" onClick={() => setSidebarOpen(false)}>
              <PlusCircle className="h-4 w-4" />
              New Invoice
            </Button>
          </NavLink>
        </div>

        {/* Nav */}
        <nav className="flex-1 space-y-0.5 px-3 py-1">
          {navItems.map(({ to, icon: Icon, label }) => (
            <NavLink
              key={to}
              to={to}
              onClick={() => setSidebarOpen(false)}
              className={({ isActive }) =>
                cn(
                  'sidebar-link',
                  isActive || location.pathname.startsWith(to + '/') ? 'active' : '',
                )
              }
            >
              <Icon className="h-4 w-4 shrink-0" />
              {label}
            </NavLink>
          ))}
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-sidebar-border">
          <div className="text-[11px] text-sidebar-muted text-center">
            QuickBill v1.0 · Local SQLite
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex flex-1 flex-col overflow-hidden">
        {/* Topbar (mobile) */}
        <header className="flex items-center gap-3 border-b border-border bg-card px-4 py-3 lg:hidden">
          <button
            onClick={() => setSidebarOpen(true)}
            className="rounded-md p-1.5 hover:bg-muted transition-colors"
          >
            <Menu className="h-5 w-5" />
          </button>
          <div className="flex items-center gap-2">
            <div className="flex h-6 w-6 items-center justify-center rounded bg-primary">
              <Zap className="h-3 w-3 text-white" />
            </div>
            <span className="font-display font-semibold text-base">QuickBill</span>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto">
          <div className="page-enter h-full">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  )
}
