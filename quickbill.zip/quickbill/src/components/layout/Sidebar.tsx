import { NavLink, useLocation } from 'react-router-dom'
import {
  LayoutDashboard, FileText, Users, Settings, Zap,
  PlusCircle, ChevronRight,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useQuery } from '@tanstack/react-query'
import { api } from '@/lib/api'

const navItems = [
  { to: '/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/invoices', icon: FileText, label: 'Invoices' },
  { to: '/clients', icon: Users, label: 'Clients' },
  { to: '/settings', icon: Settings, label: 'Settings' },
]

export default function Sidebar() {
  const location = useLocation()
  const { data: settings } = useQuery({ queryKey: ['settings'], queryFn: api.settings.get })

  return (
    <aside className="w-60 flex flex-col h-full bg-sidebar border-r border-sidebar-border shrink-0">
      {/* Brand */}
      <div className="px-6 py-6 border-b border-sidebar-border">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
            <Zap className="w-4 h-4 text-primary" strokeWidth={2.5} />
          </div>
          <div>
            <p className="font-display text-lg font-semibold text-sidebar-foreground leading-none">QuickBill</p>
            <p className="text-[10px] text-sidebar-muted mt-0.5 font-mono uppercase tracking-wider">
              {settings?.business_name || 'My Business'}
            </p>
          </div>
        </div>
      </div>

      {/* New Invoice CTA */}
      <div className="px-4 pt-4">
        <NavLink
          to="/invoices/new"
          className="flex items-center gap-2 w-full bg-primary hover:bg-primary/90 text-primary-foreground rounded-lg px-4 py-2.5 text-sm font-semibold transition-all duration-150 shadow-sm hover:shadow"
        >
          <PlusCircle className="w-4 h-4" />
          New Invoice
        </NavLink>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 pt-4 space-y-0.5">
        {navItems.map(({ to, icon: Icon, label }) => {
          const active = location.pathname === to || (to !== '/dashboard' && location.pathname.startsWith(to))
          return (
            <NavLink
              key={to}
              to={to}
              className={cn(
                'group flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150',
                active
                  ? 'bg-white/10 text-sidebar-foreground'
                  : 'text-sidebar-muted hover:bg-white/5 hover:text-sidebar-foreground'
              )}
            >
              <Icon className={cn('w-4 h-4 shrink-0', active ? 'text-primary' : '')} />
              {label}
              {active && <ChevronRight className="w-3 h-3 ml-auto text-primary" />}
            </NavLink>
          )
        })}
      </nav>

      {/* Footer */}
      <div className="px-4 py-4 border-t border-sidebar-border">
        <p className="text-[10px] text-sidebar-muted/60 font-mono text-center">
          QuickBill v1.0 — Production Ready
        </p>
      </div>
    </aside>
  )
}
