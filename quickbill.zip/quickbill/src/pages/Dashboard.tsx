import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import {
  TrendingUp, DollarSign, Clock, AlertCircle,
  FileText, ArrowRight, BarChart3,
} from 'lucide-react'
import { api } from '@/lib/api'
import { formatCurrency, formatDate, statusColor, statusLabel } from '@/lib/utils'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

export default function Dashboard() {
  const { data, isLoading } = useQuery({ queryKey: ['dashboard'], queryFn: api.dashboard.get })
  const { data: settings } = useQuery({ queryKey: ['settings'], queryFn: api.settings.get })

  const sym = settings?.currency_symbol || '$'

  if (isLoading) return (
    <div className="flex items-center justify-center h-full">
      <div className="text-muted-foreground text-sm animate-pulse">Loading dashboard…</div>
    </div>
  )

  const stats = data?.stats
  const monthly = data?.monthly || []
  const maxBilled = Math.max(...monthly.map(m => m.billed), 1)

  const statCards = [
    {
      label: 'Total Billed',
      value: formatCurrency(stats?.total_billed || 0, sym),
      icon: DollarSign,
      color: 'text-primary',
      bg: 'bg-primary/10',
      sub: `${stats?.total_invoices || 0} invoices total`,
    },
    {
      label: 'Collected',
      value: formatCurrency(stats?.total_paid || 0, sym),
      icon: TrendingUp,
      color: 'text-emerald-600',
      bg: 'bg-emerald-50',
      sub: `${stats?.paid_count || 0} paid invoices`,
    },
    {
      label: 'Outstanding',
      value: formatCurrency(stats?.total_outstanding || 0, sym),
      icon: Clock,
      color: 'text-blue-600',
      bg: 'bg-blue-50',
      sub: `${stats?.sent_count || 0} sent, awaiting payment`,
    },
    {
      label: 'Overdue',
      value: String(stats?.overdue_count || 0),
      icon: AlertCircle,
      color: 'text-red-500',
      bg: 'bg-red-50',
      sub: 'invoices past due date',
    },
  ]

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8 animate-in">
      {/* Header */}
      <div>
        <h1 className="font-display text-3xl font-semibold text-foreground">
          Good {getGreeting()}, {settings?.business_name || 'there'} 👋
        </h1>
        <p className="text-muted-foreground mt-1">Here's your financial overview</p>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {statCards.map((s) => (
          <Card key={s.label} className="hover:shadow-md transition-shadow">
            <CardContent className="p-5">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{s.label}</p>
                  <p className="text-2xl font-display font-semibold mt-1.5 text-foreground">{s.value}</p>
                  <p className="text-xs text-muted-foreground mt-1">{s.sub}</p>
                </div>
                <div className={`w-10 h-10 rounded-xl ${s.bg} flex items-center justify-center shrink-0`}>
                  <s.icon className={`w-5 h-5 ${s.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts + Recent */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Monthly Bar Chart */}
        <Card className="xl:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-primary" />
              Revenue — Last 6 Months
            </CardTitle>
          </CardHeader>
          <CardContent>
            {monthly.length === 0 ? (
              <div className="h-40 flex items-center justify-center text-muted-foreground text-sm">
                No invoice data yet
              </div>
            ) : (
              <div className="flex items-end gap-3 h-48 pt-4">
                {monthly.map((m) => (
                  <div key={m.month} className="flex-1 flex flex-col items-center gap-1.5">
                    <div className="w-full flex flex-col items-center gap-0.5" style={{ height: '160px', justifyContent: 'flex-end' }}>
                      <div className="relative w-full group">
                        {/* Billed bar */}
                        <div
                          className="w-full bg-primary/20 rounded-t-md transition-all duration-500 relative"
                          style={{ height: `${(m.billed / maxBilled) * 140}px` }}
                        >
                          {/* Collected bar overlay */}
                          <div
                            className="absolute bottom-0 left-0 right-0 bg-primary rounded-t-md transition-all duration-500"
                            style={{ height: `${(m.collected / maxBilled) * 140}px` }}
                          />
                        </div>
                        {/* Tooltip */}
                        <div className="absolute -top-10 left-1/2 -translate-x-1/2 bg-foreground text-background text-xs rounded px-2 py-1 whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10">
                          {formatCurrency(m.billed, sym)}
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-muted-foreground">
                      {m.month.slice(5)}
                    </span>
                  </div>
                ))}
              </div>
            )}
            <div className="flex items-center gap-4 mt-3 pt-3 border-t border-border">
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-sm bg-primary/20" />
                <span className="text-xs text-muted-foreground">Billed</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-sm bg-primary" />
                <span className="text-xs text-muted-foreground">Collected</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recent Invoices */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-primary" />
                Recent
              </CardTitle>
              <Link to="/invoices" className="text-xs text-primary hover:underline flex items-center gap-0.5">
                View all <ArrowRight className="w-3 h-3" />
              </Link>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {(data?.recent || []).length === 0 ? (
              <div className="px-6 py-8 text-center text-muted-foreground text-sm">
                No invoices yet.<br />
                <Link to="/invoices/new" className="text-primary hover:underline">Create your first invoice</Link>
              </div>
            ) : (
              <div className="divide-y divide-border">
                {(data?.recent || []).map((inv) => (
                  <Link
                    key={inv.id}
                    to={`/invoices/${inv.id}`}
                    className="flex items-center justify-between px-5 py-3 hover:bg-muted/50 transition-colors group"
                  >
                    <div className="min-w-0">
                      <p className="text-sm font-medium truncate">{inv.client_name || inv.client_company}</p>
                      <p className="text-xs font-mono text-muted-foreground">{inv.invoice_number}</p>
                    </div>
                    <div className="text-right shrink-0 ml-3">
                      <p className="text-sm font-semibold">{formatCurrency(inv.total, inv.currency_symbol || sym)}</p>
                      <span className={`status-badge text-[10px] mt-0.5 ${statusColor(inv.status)}`}>
                        {statusLabel(inv.status)}
                      </span>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Top Clients */}
      {(data?.topClients || []).length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Top Clients</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-border">
              {(data?.topClients || []).map((c, i) => (
                <div key={i} className="flex items-center gap-4 px-6 py-3">
                  <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center text-xs font-bold text-primary">
                    {i + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">{c.client_name}</p>
                    {c.client_company && <p className="text-xs text-muted-foreground">{c.client_company}</p>}
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold">{formatCurrency(c.total_billed, sym)}</p>
                    <p className="text-xs text-muted-foreground">{c.invoice_count} invoice{c.invoice_count !== 1 ? 's' : ''}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

function getGreeting(): string {
  const h = new Date().getHours()
  if (h < 12) return 'morning'
  if (h < 18) return 'afternoon'
  return 'evening'
}
