import { useEffect } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useForm } from 'react-hook-form'
import { toast } from 'sonner'
import { Save, Building2, Palette, Receipt, CreditCard } from 'lucide-react'
import { api, type Settings } from '@/lib/api'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'

const CURRENCIES = [
  { code: 'USD', symbol: '$', label: 'US Dollar' },
  { code: 'EUR', symbol: '€', label: 'Euro' },
  { code: 'GBP', symbol: '£', label: 'British Pound' },
  { code: 'CAD', symbol: 'CA$', label: 'Canadian Dollar' },
  { code: 'AUD', symbol: 'A$', label: 'Australian Dollar' },
  { code: 'JPY', symbol: '¥', label: 'Japanese Yen' },
  { code: 'CHF', symbol: 'Fr', label: 'Swiss Franc' },
  { code: 'INR', symbol: '₹', label: 'Indian Rupee' },
  { code: 'BRL', symbol: 'R$', label: 'Brazilian Real' },
  { code: 'MAD', symbol: 'MAD', label: 'Moroccan Dirham' },
  { code: 'DZD', symbol: 'DA', label: 'Algerian Dinar' },
  { code: 'TND', symbol: 'DT', label: 'Tunisian Dinar' },
]

export default function Settings() {
  const qc = useQueryClient()
  const { data: settings } = useQuery({ queryKey: ['settings'], queryFn: api.settings.get })

  const { register, handleSubmit, reset, watch, setValue } = useForm<Partial<Settings>>()

  useEffect(() => {
    if (settings) reset(settings)
  }, [settings, reset])

  const saveMutation = useMutation({
    mutationFn: (data: Partial<Settings>) => api.settings.update(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['settings'] })
      toast.success('Settings saved')
    },
    onError: (e: Error) => toast.error(e.message),
  })

  const onSubmit = (data: Partial<Settings>) => saveMutation.mutate(data)

  const watchCurrency = watch('currency')

  return (
    <div className="p-8 max-w-3xl mx-auto space-y-6 animate-in">
      <div>
        <h1 className="font-display text-3xl font-semibold">Settings</h1>
        <p className="text-muted-foreground mt-0.5 text-sm">Configure your business profile and invoice defaults</p>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        {/* Business Info */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="w-4 h-4 text-primary" /> Business Profile
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <Label className="mb-1.5 block">Business Name</Label>
                <Input {...register('business_name')} placeholder="My Business LLC" />
              </div>
              <div>
                <Label className="mb-1.5 block">Email</Label>
                <Input {...register('business_email')} type="email" placeholder="hello@mybusiness.com" />
              </div>
              <div>
                <Label className="mb-1.5 block">Phone</Label>
                <Input {...register('business_phone')} placeholder="+1 555 000 0000" />
              </div>
              <div className="col-span-2">
                <Label className="mb-1.5 block">Street Address</Label>
                <Input {...register('business_address')} placeholder="123 Business Ave" />
              </div>
              <div>
                <Label className="mb-1.5 block">City</Label>
                <Input {...register('business_city')} placeholder="New York" />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="mb-1.5 block">State</Label>
                  <Input {...register('business_state')} placeholder="NY" />
                </div>
                <div>
                  <Label className="mb-1.5 block">ZIP</Label>
                  <Input {...register('business_zip')} placeholder="10001" />
                </div>
              </div>
              <div>
                <Label className="mb-1.5 block">Country</Label>
                <Input {...register('business_country')} placeholder="United States" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Invoice Defaults */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Receipt className="w-4 h-4 text-primary" /> Invoice Defaults
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label className="mb-1.5 block">Invoice Prefix</Label>
                <Input {...register('invoice_prefix')} placeholder="INV" className="font-mono" />
              </div>
              <div>
                <Label className="mb-1.5 block">Payment Terms</Label>
                <Input {...register('payment_terms')} placeholder="Net 30" />
              </div>
              <div>
                <Label className="mb-1.5 block">Default Tax %</Label>
                <Input {...register('default_tax_rate', { valueAsNumber: true })} type="number" min="0" max="100" step="0.1" placeholder="0" />
              </div>
            </div>
            <div>
              <Label className="mb-1.5 block">Tax Label</Label>
              <Input {...register('tax_label')} placeholder="Tax / VAT / GST" className="max-w-xs" />
            </div>
            <div>
              <Label className="mb-1.5 block">Default Payment Instructions / Footer</Label>
              <Textarea {...register('payment_instructions')} placeholder="Bank transfer details, PayPal, payment link…" className="h-24" />
            </div>
          </CardContent>
        </Card>

        {/* Currency */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-primary" /> Currency
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="mb-1.5 block">Currency</Label>
                <select
                  {...register('currency')}
                  onChange={e => {
                    const cur = CURRENCIES.find(c => c.code === e.target.value)
                    if (cur) {
                      setValue('currency', cur.code)
                      setValue('currency_symbol', cur.symbol)
                    }
                  }}
                  className="flex h-9 w-full rounded-lg border border-input bg-background px-3 py-1 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  {CURRENCIES.map(c => (
                    <option key={c.code} value={c.code}>{c.code} — {c.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <Label className="mb-1.5 block">Currency Symbol</Label>
                <Input {...register('currency_symbol')} placeholder="$" className="max-w-28 font-mono" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Branding */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Palette className="w-4 h-4 text-primary" /> Branding
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="mb-1.5 block">Logo URL</Label>
              <Input {...register('logo_url')} placeholder="https://yourdomain.com/logo.png" />
              <p className="text-xs text-muted-foreground mt-1">Appears on invoice documents (PNG/SVG recommended)</p>
            </div>
            <div>
              <Label className="mb-1.5 block">Accent Color</Label>
              <div className="flex items-center gap-3">
                <input
                  type="color"
                  {...register('accent_color')}
                  className="w-10 h-10 rounded-lg border border-input cursor-pointer bg-transparent"
                />
                <Input {...register('accent_color')} placeholder="#DC8A3C" className="font-mono max-w-36" />
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end">
          <Button type="submit" disabled={saveMutation.isPending} size="lg">
            <Save className="w-4 h-4" />
            {saveMutation.isPending ? 'Saving…' : 'Save Settings'}
          </Button>
        </div>
      </form>
    </div>
  )
}
