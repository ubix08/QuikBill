import { useEffect, useState, useCallback } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useForm, useFieldArray, Controller } from 'react-hook-form'
import { toast } from 'sonner'
import { Plus, Trash2, ArrowLeft, Save, Send, GripVertical } from 'lucide-react'
import { api, type Invoice, type InvoiceItem } from '@/lib/api'
import { today, addDays } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Separator } from '@/components/ui/separator'

interface FormValues {
  invoice_number: string
  issue_date: string
  due_date: string
  payment_terms: string
  status: string
  client_name: string
  client_email: string
  client_company: string
  client_address: string
  client_city: string
  client_state: string
  client_zip: string
  client_country: string
  items: InvoiceItem[]
  tax_rate: number
  discount_type: 'percent' | 'fixed'
  discount_value: number
  notes: string
  footer_note: string
}

const PAYMENT_TERMS = ['Due on Receipt', 'Net 7', 'Net 15', 'Net 30', 'Net 60', 'Net 90']

export default function InvoiceEditor() {
  const { id } = useParams()
  const navigate = useNavigate()
  const qc = useQueryClient()
  const isEdit = Boolean(id)

  const { data: settings } = useQuery({ queryKey: ['settings'], queryFn: api.settings.get })
  const { data: clients } = useQuery({ queryKey: ['clients'], queryFn: api.clients.list })
  const { data: existing } = useQuery({
    queryKey: ['invoice', id],
    queryFn: () => api.invoices.get(Number(id)),
    enabled: isEdit,
  })

  const sym = settings?.currency_symbol || '$'

  const { register, control, watch, setValue, handleSubmit, reset } = useForm<FormValues>({
    defaultValues: {
      invoice_number: '',
      issue_date: today(),
      due_date: addDays(today(), 30),
      payment_terms: 'Net 30',
      status: 'draft',
      client_name: '',
      client_email: '',
      client_company: '',
      client_address: '',
      client_city: '',
      client_state: '',
      client_zip: '',
      client_country: '',
      items: [{ description: '', details: '', quantity: 1, rate: 0, amount: 0 }],
      tax_rate: 0,
      discount_type: 'percent',
      discount_value: 0,
      notes: '',
      footer_note: '',
    },
  })

  const { fields, append, remove } = useFieldArray({ control, name: 'items' })

  // Populate from existing
  useEffect(() => {
    if (existing) {
      reset({
        invoice_number: existing.invoice_number,
        issue_date: existing.issue_date,
        due_date: existing.due_date,
        payment_terms: existing.payment_terms,
        status: existing.status,
        client_name: existing.client_name,
        client_email: existing.client_email,
        client_company: existing.client_company,
        client_address: existing.client_address,
        client_city: existing.client_city,
        client_state: existing.client_state,
        client_zip: existing.client_zip,
        client_country: existing.client_country,
        items: existing.items?.length ? existing.items : [{ description: '', details: '', quantity: 1, rate: 0, amount: 0 }],
        tax_rate: existing.tax_rate,
        discount_type: existing.discount_type as 'percent' | 'fixed',
        discount_value: existing.discount_value,
        notes: existing.notes,
        footer_note: existing.footer_note,
      })
    }
  }, [existing, reset])

  // Populate defaults from settings
  useEffect(() => {
    if (settings && !isEdit) {
      setValue('tax_rate', settings.default_tax_rate)
      setValue('footer_note', settings.payment_instructions)
      setValue('payment_terms', settings.payment_terms)
    }
  }, [settings, isEdit, setValue])

  // Watch items for live totals
  const watchedItems = watch('items')
  const taxRate = watch('tax_rate')
  const discountType = watch('discount_type')
  const discountValue = watch('discount_value')

  // Auto-calculate item amounts
  useEffect(() => {
    watchedItems.forEach((item, idx) => {
      const amount = Number(item.quantity || 0) * Number(item.rate || 0)
      if (item.amount !== amount) setValue(`items.${idx}.amount`, amount)
    })
  }, [watchedItems.map(i => `${i.quantity}:${i.rate}`).join(',')])

  const subtotal = watchedItems.reduce((s, i) => s + Number(i.quantity || 0) * Number(i.rate || 0), 0)
  const discountAmount = discountType === 'percent' ? subtotal * (discountValue / 100) : Number(discountValue)
  const taxableAmount = subtotal - discountAmount
  const taxAmount = taxableAmount * (taxRate / 100)
  const total = taxableAmount + taxAmount

  const handleTermsChange = (terms: string) => {
    setValue('payment_terms', terms)
    const days = parseInt(terms.replace('Net ', '')) || 0
    if (terms === 'Due on Receipt') setValue('due_date', watch('issue_date'))
    else setValue('due_date', addDays(watch('issue_date'), days))
  }

  const handleClientSelect = (clientId: string) => {
    const client = clients?.find(c => String(c.id) === clientId)
    if (client) {
      setValue('client_name', client.name)
      setValue('client_email', client.email)
      setValue('client_company', client.company)
      setValue('client_address', client.address)
      setValue('client_city', client.city)
      setValue('client_state', client.state)
      setValue('client_zip', client.zip)
      setValue('client_country', client.country)
    }
  }

  const saveMutation = useMutation({
    mutationFn: (data: Partial<Invoice>) =>
      isEdit ? api.invoices.update(Number(id), data) : api.invoices.create(data),
    onSuccess: (inv) => {
      qc.invalidateQueries({ queryKey: ['invoices'] })
      qc.invalidateQueries({ queryKey: ['dashboard'] })
      toast.success(isEdit ? 'Invoice updated' : 'Invoice created')
      navigate(`/invoices/${inv.id}`)
    },
    onError: (e: Error) => toast.error(e.message),
  })

  const onSubmit = (values: FormValues, status?: string) => {
    saveMutation.mutate({
      ...values,
      status: (status || values.status) as Invoice['status'],
      subtotal,
      tax_amount: taxAmount,
      discount_amount: discountAmount,
      total,
      currency: settings?.currency || 'USD',
      currency_symbol: sym,
    })
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Top bar */}
      <div className="sticky top-0 z-10 bg-background/80 backdrop-blur border-b border-border">
        <div className="max-w-5xl mx-auto px-6 py-3 flex items-center justify-between">
          <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-4 h-4" /> Back
          </button>
          <h1 className="font-display text-lg font-semibold">
            {isEdit ? `Edit Invoice` : 'New Invoice'}
          </h1>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handleSubmit(v => onSubmit(v, 'draft'))} disabled={saveMutation.isPending}>
              <Save className="w-3.5 h-3.5" /> Save Draft
            </Button>
            <Button size="sm" onClick={handleSubmit(v => onSubmit(v, 'sent'))} disabled={saveMutation.isPending}>
              <Send className="w-3.5 h-3.5" /> Save & Send
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-8 space-y-8">
        {/* Header section */}
        <div className="grid grid-cols-2 gap-8">
          {/* Invoice Meta */}
          <div className="space-y-4">
            <div>
              <Label className="mb-1.5 block">Invoice Number</Label>
              <Input {...register('invoice_number')} placeholder="INV-01000" className="font-mono" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="mb-1.5 block">Issue Date</Label>
                <Input type="date" {...register('issue_date')} />
              </div>
              <div>
                <Label className="mb-1.5 block">Due Date</Label>
                <Input type="date" {...register('due_date')} />
              </div>
            </div>
            <div>
              <Label className="mb-1.5 block">Payment Terms</Label>
              <Controller
                name="payment_terms"
                control={control}
                render={({ field }) => (
                  <Select value={field.value} onValueChange={handleTermsChange}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {PAYMENT_TERMS.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                    </SelectContent>
                  </Select>
                )}
              />
            </div>
          </div>

          {/* Client section */}
          <div className="space-y-4">
            <div>
              <Label className="mb-1.5 block">Bill To</Label>
              {clients && clients.length > 0 && (
                <Select onValueChange={handleClientSelect}>
                  <SelectTrigger className="mb-2">
                    <SelectValue placeholder="Select existing client…" />
                  </SelectTrigger>
                  <SelectContent>
                    {clients.map(c => (
                      <SelectItem key={c.id} value={String(c.id)}>
                        {c.name}{c.company ? ` — ${c.company}` : ''}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
              <Input {...register('client_name')} placeholder="Client name" className="mb-2" />
              <Input {...register('client_company')} placeholder="Company (optional)" className="mb-2" />
              <Input {...register('client_email')} placeholder="Email address" type="email" />
            </div>
            <Textarea
              {...register('client_address')}
              placeholder="Address, City, State ZIP, Country"
              className="h-20 text-sm"
            />
          </div>
        </div>

        <Separator />

        {/* Line Items */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display font-semibold text-lg">Line Items</h2>
          </div>

          {/* Table header */}
          <div className="grid grid-cols-[1fr_80px_100px_90px_28px] gap-3 mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground px-2">
            <span>Description</span>
            <span>Qty</span>
            <span>Rate</span>
            <span className="text-right">Amount</span>
            <span></span>
          </div>

          <div className="space-y-2">
            {fields.map((field, idx) => (
              <div key={field.id} className="grid grid-cols-[1fr_80px_100px_90px_28px] gap-3 items-start group">
                <div className="space-y-1">
                  <Input {...register(`items.${idx}.description`)} placeholder="Item description" />
                  <Input
                    {...register(`items.${idx}.details`)}
                    placeholder="Additional details (optional)"
                    className="text-xs h-7 text-muted-foreground"
                  />
                </div>
                <Input
                  type="number"
                  min="0"
                  step="0.01"
                  {...register(`items.${idx}.quantity`, { valueAsNumber: true })}
                  className="text-center"
                />
                <div className="relative">
                  <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">{sym}</span>
                  <Input
                    type="number"
                    min="0"
                    step="0.01"
                    {...register(`items.${idx}.rate`, { valueAsNumber: true })}
                    className="pl-6"
                  />
                </div>
                <div className="flex items-center h-9 justify-end font-semibold text-sm font-display">
                  {sym}{((watchedItems[idx]?.quantity || 0) * (watchedItems[idx]?.rate || 0)).toFixed(2)}
                </div>
                <button
                  type="button"
                  onClick={() => fields.length > 1 && remove(idx)}
                  className="flex items-center justify-center h-9 w-7 rounded-md text-muted-foreground hover:text-red-500 hover:bg-red-50 transition-colors opacity-0 group-hover:opacity-100"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>

          <Button
            type="button"
            variant="outline"
            size="sm"
            className="mt-3"
            onClick={() => append({ description: '', details: '', quantity: 1, rate: 0, amount: 0 })}
          >
            <Plus className="w-3.5 h-3.5" /> Add Line Item
          </Button>
        </div>

        <Separator />

        {/* Totals + Notes */}
        <div className="grid grid-cols-2 gap-12">
          {/* Notes */}
          <div className="space-y-4">
            <div>
              <Label className="mb-1.5 block">Notes to Client</Label>
              <Textarea {...register('notes')} placeholder="Thank you for your business…" className="h-24" />
            </div>
            <div>
              <Label className="mb-1.5 block">Payment Instructions / Footer</Label>
              <Textarea {...register('footer_note')} placeholder="Bank details, payment link…" className="h-20" />
            </div>
          </div>

          {/* Totals */}
          <div className="space-y-3">
            <div className="flex justify-between items-center text-sm">
              <span className="text-muted-foreground">Subtotal</span>
              <span className="font-mono">{sym}{subtotal.toFixed(2)}</span>
            </div>

            <div className="flex justify-between items-center gap-4">
              <div className="flex items-center gap-2 flex-1">
                <span className="text-sm text-muted-foreground whitespace-nowrap">Discount</span>
                <Controller
                  name="discount_type"
                  control={control}
                  render={({ field }) => (
                    <Select value={field.value} onValueChange={field.onChange}>
                      <SelectTrigger className="h-7 text-xs w-20">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="percent">%</SelectItem>
                        <SelectItem value="fixed">{sym}</SelectItem>
                      </SelectContent>
                    </Select>
                  )}
                />
                <Input
                  type="number"
                  min="0"
                  step="0.01"
                  {...register('discount_value', { valueAsNumber: true })}
                  className="h-7 text-xs w-24"
                />
              </div>
              <span className="font-mono text-sm text-red-500">-{sym}{discountAmount.toFixed(2)}</span>
            </div>

            <div className="flex justify-between items-center gap-4">
              <div className="flex items-center gap-2 flex-1">
                <span className="text-sm text-muted-foreground whitespace-nowrap">Tax %</span>
                <Input
                  type="number"
                  min="0"
                  max="100"
                  step="0.1"
                  {...register('tax_rate', { valueAsNumber: true })}
                  className="h-7 text-xs w-24"
                />
              </div>
              <span className="font-mono text-sm">+{sym}{taxAmount.toFixed(2)}</span>
            </div>

            <Separator />

            <div className="flex justify-between items-center">
              <span className="font-display font-semibold text-lg">Total</span>
              <span className="font-display font-bold text-2xl text-primary">
                {sym}{total.toFixed(2)}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
