import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { PlusCircle, Search, Filter, Trash2, Eye, Pencil, MoreVertical } from 'lucide-react'
import { toast } from 'sonner'
import { api } from '@/lib/api'
import { formatCurrency, formatDate, statusColor, statusLabel } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import * as DropdownMenu from '@radix-ui/react-dropdown-menu'

const STATUSES = ['all', 'draft', 'sent', 'paid', 'overdue', 'cancelled']

export default function InvoiceList() {
  const [status, setStatus] = useState('all')
  const [search, setSearch] = useState('')
  const navigate = useNavigate()
  const qc = useQueryClient()

  const { data, isLoading } = useQuery({
    queryKey: ['invoices', status, search],
    queryFn: () => api.invoices.list({ status: status === 'all' ? undefined : status, search: search || undefined }),
  })

  const { data: settings } = useQuery({ queryKey: ['settings'], queryFn: api.settings.get })
  const sym = settings?.currency_symbol || '$'

  const deleteMutation = useMutation({
    mutationFn: (id: number) => api.invoices.delete(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['invoices'] })
      qc.invalidateQueries({ queryKey: ['dashboard'] })
      toast.success('Invoice deleted')
    },
  })

  const statusMutation = useMutation({
    mutationFn: ({ id, status }: { id: number; status: string }) => api.invoices.updateStatus(id, status),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['invoices'] })
      qc.invalidateQueries({ queryKey: ['dashboard'] })
      toast.success('Status updated')
    },
  })

  const invoices = data?.invoices || []

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6 animate-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl font-semibold">Invoices</h1>
          <p className="text-muted-foreground mt-0.5 text-sm">{data?.total ?? 0} total invoices</p>
        </div>
        <Link to="/invoices/new">
          <Button className="gap-2">
            <PlusCircle className="w-4 h-4" /> New Invoice
          </Button>
        </Link>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search by client or invoice #…"
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="w-40">
          <Select value={status} onValueChange={setStatus}>
            <SelectTrigger>
              <Filter className="w-3.5 h-3.5 mr-1.5 text-muted-foreground" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {STATUSES.map(s => (
                <SelectItem key={s} value={s}>{s === 'all' ? 'All Status' : statusLabel(s)}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Table */}
      <div className="rounded-xl border border-border bg-card overflow-hidden shadow-sm">
        {isLoading ? (
          <div className="p-16 text-center text-muted-foreground text-sm animate-pulse">Loading…</div>
        ) : invoices.length === 0 ? (
          <div className="p-16 text-center">
            <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center mx-auto mb-3">
              <PlusCircle className="w-6 h-6 text-muted-foreground" />
            </div>
            <p className="text-muted-foreground font-medium">No invoices found</p>
            <p className="text-sm text-muted-foreground mt-1">
              {search || status !== 'all' ? 'Try adjusting your filters' : 'Create your first invoice to get started'}
            </p>
            {!search && status === 'all' && (
              <Link to="/invoices/new">
                <Button className="mt-4" size="sm">Create Invoice</Button>
              </Link>
            )}
          </div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                <th className="text-left px-5 py-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Invoice</th>
                <th className="text-left px-5 py-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Client</th>
                <th className="text-left px-5 py-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Due</th>
                <th className="text-left px-5 py-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Status</th>
                <th className="text-right px-5 py-3 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Amount</th>
                <th className="px-5 py-3 w-10"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {invoices.map((inv) => (
                <tr key={inv.id} className="hover:bg-muted/30 transition-colors group">
                  <td className="px-5 py-3.5">
                    <span className="font-mono text-xs font-medium text-muted-foreground">{inv.invoice_number}</span>
                  </td>
                  <td className="px-5 py-3.5">
                    <p className="font-medium">{inv.client_name || '—'}</p>
                    {inv.client_company && <p className="text-xs text-muted-foreground">{inv.client_company}</p>}
                  </td>
                  <td className="px-5 py-3.5 text-muted-foreground">{formatDate(inv.due_date)}</td>
                  <td className="px-5 py-3.5">
                    <span className={`status-badge ${statusColor(inv.status)}`}>{statusLabel(inv.status)}</span>
                  </td>
                  <td className="px-5 py-3.5 text-right font-semibold font-display">
                    {formatCurrency(inv.total, inv.currency_symbol || sym)}
                  </td>
                  <td className="px-3 py-3.5">
                    <DropdownMenu.Root>
                      <DropdownMenu.Trigger asChild>
                        <button className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-muted opacity-0 group-hover:opacity-100 transition-all">
                          <MoreVertical className="w-4 h-4" />
                        </button>
                      </DropdownMenu.Trigger>
                      <DropdownMenu.Portal>
                        <DropdownMenu.Content className="min-w-40 bg-popover border border-border rounded-lg shadow-lg p-1 z-50 text-sm">
                          <DropdownMenu.Item
                            onSelect={() => navigate(`/invoices/${inv.id}`)}
                            className="flex items-center gap-2 px-3 py-2 rounded-md cursor-pointer hover:bg-muted outline-none"
                          >
                            <Eye className="w-3.5 h-3.5" /> View
                          </DropdownMenu.Item>
                          <DropdownMenu.Item
                            onSelect={() => navigate(`/invoices/${inv.id}/edit`)}
                            className="flex items-center gap-2 px-3 py-2 rounded-md cursor-pointer hover:bg-muted outline-none"
                          >
                            <Pencil className="w-3.5 h-3.5" /> Edit
                          </DropdownMenu.Item>
                          <DropdownMenu.Separator className="my-1 h-px bg-border" />
                          {['draft','sent','paid','overdue'].filter(s => s !== inv.status).map(s => (
                            <DropdownMenu.Item
                              key={s}
                              onSelect={() => statusMutation.mutate({ id: inv.id, status: s })}
                              className="flex items-center gap-2 px-3 py-2 rounded-md cursor-pointer hover:bg-muted outline-none capitalize"
                            >
                              Mark as {s}
                            </DropdownMenu.Item>
                          ))}
                          <DropdownMenu.Separator className="my-1 h-px bg-border" />
                          <DropdownMenu.Item
                            onSelect={() => {
                              if (confirm('Delete this invoice?')) deleteMutation.mutate(inv.id)
                            }}
                            className="flex items-center gap-2 px-3 py-2 rounded-md cursor-pointer hover:bg-red-50 text-red-600 outline-none"
                          >
                            <Trash2 className="w-3.5 h-3.5" /> Delete
                          </DropdownMenu.Item>
                        </DropdownMenu.Content>
                      </DropdownMenu.Portal>
                    </DropdownMenu.Root>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
