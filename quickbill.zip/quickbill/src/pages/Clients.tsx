import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useForm } from 'react-hook-form'
import { toast } from 'sonner'
import { PlusCircle, Users, Pencil, Trash2, Search, Mail, Phone, Building2 } from 'lucide-react'
import { api, type Client } from '@/lib/api'
import { formatCurrency } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog'
import { Separator } from '@/components/ui/separator'

type ClientForm = Omit<Client, 'id' | 'created_at' | 'invoice_count' | 'total_paid' | 'total_outstanding'>

export default function Clients() {
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<Client | null>(null)
  const [search, setSearch] = useState('')
  const qc = useQueryClient()

  const { data: clients = [], isLoading } = useQuery({ queryKey: ['clients'], queryFn: api.clients.list })
  const { data: settings } = useQuery({ queryKey: ['settings'], queryFn: api.settings.get })
  const sym = settings?.currency_symbol || '$'

  const { register, handleSubmit, reset } = useForm<ClientForm>()

  const saveMutation = useMutation({
    mutationFn: (data: ClientForm) =>
      editing ? api.clients.update(editing.id, data) : api.clients.create(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['clients'] })
      toast.success(editing ? 'Client updated' : 'Client created')
      setOpen(false)
      setEditing(null)
      reset()
    },
    onError: (e: Error) => toast.error(e.message),
  })

  const deleteMutation = useMutation({
    mutationFn: (id: number) => api.clients.delete(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['clients'] })
      toast.success('Client deleted')
    },
  })

  const openNew = () => { setEditing(null); reset({}); setOpen(true) }
  const openEdit = (c: Client) => {
    setEditing(c)
    reset({ name: c.name, email: c.email, phone: c.phone, company: c.company,
      address: c.address, city: c.city, state: c.state, zip: c.zip,
      country: c.country, notes: c.notes })
    setOpen(true)
  }

  const filtered = clients.filter(c =>
    !search || c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.company?.toLowerCase().includes(search.toLowerCase()) ||
    c.email?.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6 animate-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl font-semibold">Clients</h1>
          <p className="text-muted-foreground mt-0.5 text-sm">{clients.length} total clients</p>
        </div>
        <Button onClick={openNew}>
          <PlusCircle className="w-4 h-4" /> New Client
        </Button>
      </div>

      {/* Search */}
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search clients…"
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {/* Grid */}
      {isLoading ? (
        <div className="text-center text-muted-foreground text-sm py-16 animate-pulse">Loading…</div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-20">
          <div className="w-14 h-14 rounded-full bg-muted flex items-center justify-center mx-auto mb-3">
            <Users className="w-7 h-7 text-muted-foreground" />
          </div>
          <p className="font-medium text-muted-foreground">
            {search ? 'No clients match your search' : 'No clients yet'}
          </p>
          {!search && (
            <Button onClick={openNew} className="mt-4" size="sm">Add your first client</Button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map(client => (
            <div key={client.id} className="bg-card border border-border rounded-xl p-5 hover:shadow-md transition-shadow group relative">
              {/* Actions */}
              <div className="absolute top-4 right-4 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button onClick={() => openEdit(client)} className="w-7 h-7 flex items-center justify-center rounded-md hover:bg-muted text-muted-foreground hover:text-foreground transition-colors">
                  <Pencil className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => { if (confirm('Delete this client?')) deleteMutation.mutate(client.id) }}
                  className="w-7 h-7 flex items-center justify-center rounded-md hover:bg-red-50 text-muted-foreground hover:text-red-500 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Avatar */}
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mb-3">
                <span className="font-display font-semibold text-primary text-sm">
                  {client.name.charAt(0).toUpperCase()}
                </span>
              </div>

              <h3 className="font-semibold text-foreground">{client.name}</h3>
              {client.company && (
                <p className="text-sm text-muted-foreground flex items-center gap-1.5 mt-0.5">
                  <Building2 className="w-3 h-3" /> {client.company}
                </p>
              )}

              <div className="mt-3 space-y-1">
                {client.email && (
                  <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                    <Mail className="w-3 h-3" /> {client.email}
                  </p>
                )}
                {client.phone && (
                  <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                    <Phone className="w-3 h-3" /> {client.phone}
                  </p>
                )}
              </div>

              <Separator className="my-3" />

              <div className="grid grid-cols-3 gap-2 text-center">
                <div>
                  <p className="text-lg font-display font-semibold">{client.invoice_count || 0}</p>
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wide">Invoices</p>
                </div>
                <div>
                  <p className="text-lg font-display font-semibold text-emerald-600">{formatCurrency(client.total_paid || 0, sym)}</p>
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wide">Paid</p>
                </div>
                <div>
                  <p className="text-lg font-display font-semibold text-orange-500">{formatCurrency(client.total_outstanding || 0, sym)}</p>
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wide">Owed</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Client' : 'New Client'}</DialogTitle>
            <DialogDescription>Fill in the client details below.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit(d => saveMutation.mutate(d))} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <Label className="mb-1.5 block">Full Name *</Label>
                <Input {...register('name', { required: true })} placeholder="John Smith" />
              </div>
              <div>
                <Label className="mb-1.5 block">Company</Label>
                <Input {...register('company')} placeholder="Acme Inc." />
              </div>
              <div>
                <Label className="mb-1.5 block">Email</Label>
                <Input {...register('email')} type="email" placeholder="john@acme.com" />
              </div>
              <div>
                <Label className="mb-1.5 block">Phone</Label>
                <Input {...register('phone')} placeholder="+1 555 000 0000" />
              </div>
              <div>
                <Label className="mb-1.5 block">Country</Label>
                <Input {...register('country')} placeholder="United States" />
              </div>
              <div className="col-span-2">
                <Label className="mb-1.5 block">Address</Label>
                <Input {...register('address')} placeholder="123 Main St" />
              </div>
              <div>
                <Label className="mb-1.5 block">City</Label>
                <Input {...register('city')} placeholder="New York" />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="mb-1.5 block">State</Label>
                  <Input {...register('state')} placeholder="NY" />
                </div>
                <div>
                  <Label className="mb-1.5 block">ZIP</Label>
                  <Input {...register('zip')} placeholder="10001" />
                </div>
              </div>
              <div className="col-span-2">
                <Label className="mb-1.5 block">Notes</Label>
                <Textarea {...register('notes')} placeholder="Internal notes about this client…" className="h-16" />
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={saveMutation.isPending}>
                {editing ? 'Update Client' : 'Create Client'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
