import { useRef } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { ArrowLeft, Pencil, Trash2, Printer, Download, CheckCircle, Send } from 'lucide-react'
import jsPDF from 'jspdf'
import html2canvas from 'html2canvas'
import { api } from '@/lib/api'
import { formatCurrency, formatDate, statusColor, statusLabel } from '@/lib/utils'
import { Button } from '@/components/ui/button'

export default function InvoiceView() {
  const { id } = useParams()
  const navigate = useNavigate()
  const qc = useQueryClient()
  const printRef = useRef<HTMLDivElement>(null)

  const { data: inv, isLoading } = useQuery({
    queryKey: ['invoice', id],
    queryFn: () => api.invoices.get(Number(id)),
  })
  const { data: settings } = useQuery({ queryKey: ['settings'], queryFn: api.settings.get })

  const sym = inv?.currency_symbol || settings?.currency_symbol || '$'

  const statusMutation = useMutation({
    mutationFn: (status: string) => api.invoices.updateStatus(Number(id), status),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['invoice', id] })
      qc.invalidateQueries({ queryKey: ['invoices'] })
      qc.invalidateQueries({ queryKey: ['dashboard'] })
      toast.success('Status updated')
    },
  })

  const deleteMutation = useMutation({
    mutationFn: () => api.invoices.delete(Number(id)),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['invoices'] })
      toast.success('Invoice deleted')
      navigate('/invoices')
    },
  })

  const handleDownloadPDF = async () => {
    if (!printRef.current) return
    toast.loading('Generating PDF…')
    try {
      const canvas = await html2canvas(printRef.current, { scale: 2, useCORS: true, backgroundColor: '#fff' })
      const imgData = canvas.toDataURL('image/png')
      const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' })
      const pageW = pdf.internal.pageSize.getWidth()
      const pageH = (canvas.height * pageW) / canvas.width
      pdf.addImage(imgData, 'PNG', 0, 0, pageW, pageH)
      pdf.save(`${inv?.invoice_number || 'invoice'}.pdf`)
      toast.dismiss()
      toast.success('PDF downloaded')
    } catch {
      toast.dismiss()
      toast.error('PDF generation failed')
    }
  }

  const handlePrint = () => window.print()

  if (isLoading) return (
    <div className="flex items-center justify-center h-full">
      <div className="text-muted-foreground text-sm animate-pulse">Loading invoice…</div>
    </div>
  )
  if (!inv) return <div className="p-8 text-center text-muted-foreground">Invoice not found</div>

  return (
    <div className="min-h-screen bg-muted/30">
      {/* Action bar */}
      <div className="no-print sticky top-0 z-10 bg-background/80 backdrop-blur border-b border-border">
        <div className="max-w-4xl mx-auto px-6 py-3 flex items-center justify-between">
          <button onClick={() => navigate('/invoices')} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-4 h-4" /> Invoices
          </button>
          <div className="flex items-center gap-2">
            {inv.status !== 'paid' && (
              <Button size="sm" variant="success" onClick={() => statusMutation.mutate('paid')}>
                <CheckCircle className="w-3.5 h-3.5" /> Mark Paid
              </Button>
            )}
            {inv.status === 'draft' && (
              <Button size="sm" variant="outline" onClick={() => statusMutation.mutate('sent')}>
                <Send className="w-3.5 h-3.5" /> Mark Sent
              </Button>
            )}
            <Button size="sm" variant="outline" onClick={handlePrint}>
              <Printer className="w-3.5 h-3.5" /> Print
            </Button>
            <Button size="sm" variant="outline" onClick={handleDownloadPDF}>
              <Download className="w-3.5 h-3.5" /> PDF
            </Button>
            <Link to={`/invoices/${id}/edit`}>
              <Button size="sm" variant="outline">
                <Pencil className="w-3.5 h-3.5" /> Edit
              </Button>
            </Link>
            <Button
              size="sm"
              variant="outline"
              className="text-destructive hover:bg-red-50"
              onClick={() => { if (confirm('Delete this invoice?')) deleteMutation.mutate() }}
            >
              <Trash2 className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Invoice Document */}
      <div className="max-w-4xl mx-auto px-6 py-8">
        <div ref={printRef} className="invoice-preview bg-white rounded-2xl shadow-lg overflow-hidden">
          {/* Header band */}
          <div className="bg-[#18181B] text-white px-10 py-8">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-6 h-6 rounded bg-primary/20 flex items-center justify-center">
                    <span className="text-primary text-xs font-bold">Q</span>
                  </div>
                  <span className="text-sm font-mono text-white/60">{settings?.business_name || 'My Business'}</span>
                </div>
                <h1 className="font-display text-4xl font-light tracking-tight text-white">INVOICE</h1>
                <p className="font-mono text-primary mt-1 text-lg">{inv.invoice_number}</p>
              </div>
              <div className="text-right text-sm">
                <span className={`status-badge text-xs ${statusColor(inv.status)} !bg-white/10 !ring-white/20 !text-white/80`}>
                  {statusLabel(inv.status)}
                </span>
                <div className="mt-3 space-y-1 text-white/70">
                  {settings?.business_email && <p>{settings.business_email}</p>}
                  {settings?.business_phone && <p>{settings.business_phone}</p>}
                  {settings?.business_address && (
                    <p>{settings.business_address}{settings.business_city ? `, ${settings.business_city}` : ''}</p>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Dates strip */}
          <div className="bg-primary px-10 py-3 flex gap-12">
            <div>
              <p className="text-primary-foreground/70 text-[10px] font-semibold uppercase tracking-widest">Issue Date</p>
              <p className="text-primary-foreground font-medium text-sm mt-0.5">{formatDate(inv.issue_date)}</p>
            </div>
            <div>
              <p className="text-primary-foreground/70 text-[10px] font-semibold uppercase tracking-widest">Due Date</p>
              <p className="text-primary-foreground font-medium text-sm mt-0.5">{formatDate(inv.due_date)}</p>
            </div>
            <div>
              <p className="text-primary-foreground/70 text-[10px] font-semibold uppercase tracking-widest">Terms</p>
              <p className="text-primary-foreground font-medium text-sm mt-0.5">{inv.payment_terms}</p>
            </div>
          </div>

          {/* Bill To */}
          <div className="px-10 py-8">
            <div className="grid grid-cols-2 gap-8 mb-8">
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground mb-2">Bill To</p>
                <p className="font-semibold text-foreground text-lg">{inv.client_name}</p>
                {inv.client_company && <p className="text-muted-foreground">{inv.client_company}</p>}
                {inv.client_email && <p className="text-sm text-muted-foreground">{inv.client_email}</p>}
                {inv.client_address && (
                  <p className="text-sm text-muted-foreground mt-1">
                    {inv.client_address}<br />
                    {[inv.client_city, inv.client_state, inv.client_zip].filter(Boolean).join(', ')}<br />
                    {inv.client_country}
                  </p>
                )}
              </div>
            </div>

            {/* Items table */}
            <table className="w-full text-sm mb-6">
              <thead>
                <tr className="border-b-2 border-foreground/10">
                  <th className="text-left py-2 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">Description</th>
                  <th className="text-center py-2 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground w-20">Qty</th>
                  <th className="text-right py-2 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground w-28">Rate</th>
                  <th className="text-right py-2 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground w-28">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/50">
                {(inv.items || []).map((item, i) => (
                  <tr key={i}>
                    <td className="py-3 pr-4">
                      <p className="font-medium">{item.description}</p>
                      {item.details && <p className="text-xs text-muted-foreground mt-0.5">{item.details}</p>}
                    </td>
                    <td className="py-3 text-center text-muted-foreground">{item.quantity}</td>
                    <td className="py-3 text-right text-muted-foreground">{formatCurrency(item.rate, sym)}</td>
                    <td className="py-3 text-right font-semibold">{formatCurrency(item.amount, sym)}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* Totals */}
            <div className="flex justify-end">
              <div className="w-64 space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>{formatCurrency(inv.subtotal, sym)}</span>
                </div>
                {inv.discount_amount > 0 && (
                  <div className="flex justify-between text-red-600">
                    <span>Discount</span>
                    <span>-{formatCurrency(inv.discount_amount, sym)}</span>
                  </div>
                )}
                {inv.tax_rate > 0 && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">{settings?.tax_label || 'Tax'} ({inv.tax_rate}%)</span>
                    <span>{formatCurrency(inv.tax_amount, sym)}</span>
                  </div>
                )}
                <div className="flex justify-between items-center pt-3 border-t-2 border-foreground/20">
                  <span className="font-display font-bold text-base">Total Due</span>
                  <span className="font-display font-bold text-2xl text-primary">{formatCurrency(inv.total, sym)}</span>
                </div>
                {inv.amount_paid > 0 && (
                  <div className="flex justify-between text-emerald-600">
                    <span>Amount Paid</span>
                    <span>-{formatCurrency(inv.amount_paid, sym)}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Notes & Footer */}
            {(inv.notes || inv.footer_note) && (
              <div className="mt-8 pt-6 border-t border-border space-y-4">
                {inv.notes && (
                  <div>
                    <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground mb-1">Notes</p>
                    <p className="text-sm text-muted-foreground">{inv.notes}</p>
                  </div>
                )}
                {inv.footer_note && (
                  <div>
                    <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground mb-1">Payment Instructions</p>
                    <p className="text-sm text-muted-foreground whitespace-pre-line">{inv.footer_note}</p>
                  </div>
                )}
              </div>
            )}

            {/* Footer */}
            <div className="mt-10 pt-6 border-t border-border/50 text-center">
              <p className="text-xs text-muted-foreground/60 font-mono">
                Generated by QuickBill · {settings?.business_name}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
