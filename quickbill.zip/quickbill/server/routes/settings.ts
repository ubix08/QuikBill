import { Router } from 'express'
import { getDb } from '../db.js'

export const settingsRouter = Router()

settingsRouter.get('/', (_req, res) => {
  try {
    const db = getDb()
    const settings = db.prepare('SELECT * FROM settings WHERE id = 1').get()
    res.json(settings)
  } catch (e: any) {
    res.status(500).json({ error: e.message })
  }
})

settingsRouter.put('/', (req, res) => {
  try {
    const db = getDb()
    const fields = [
      'business_name','business_email','business_phone','business_address',
      'business_city','business_state','business_zip','business_country',
      'logo_url','currency','currency_symbol','tax_label','default_tax_rate',
      'invoice_prefix','payment_terms','payment_instructions','accent_color',
    ]
    const body = req.body
    const setClauses = fields
      .filter(f => body[f] !== undefined)
      .map(f => `${f} = @${f}`)
      .join(', ')

    if (!setClauses) return res.json({ message: 'nothing to update' })

    db.prepare(`UPDATE settings SET ${setClauses}, updated_at = CURRENT_TIMESTAMP WHERE id = 1`)
      .run(body)

    const updated = db.prepare('SELECT * FROM settings WHERE id = 1').get()
    res.json(updated)
  } catch (e: any) {
    res.status(500).json({ error: e.message })
  }
})
