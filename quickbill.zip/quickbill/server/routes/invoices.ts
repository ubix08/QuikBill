import { Router } from 'express'
import { getDb } from '../db.js'

export const invoicesRouter = Router()

invoicesRouter.get('/', (req, res) => {
  try {
    const db = getDb()
    const { status, search, limit = '50', offset = '0' } = req.query as Record<string, string>
    let where = 'WHERE 1=1'
    const params: Record<string, string | number> = {}
    if (status && status !== 'all') { where += ' AND i.status = @status'; params.status = status }
    if (search) {
      where += ` AND (i.invoice_number LIKE @search OR i.client_name LIKE @search OR i.client_company LIKE @search)`
      params.search = `%${search}%`
    }
    params.limit = parseInt(limit)
    params.offset = parseInt(offset)

    const invoices = db.prepare(`
      SELECT i.*, GROUP_CONCAT(ii.description, ', ') AS item_descriptions
      FROM invoices i
      LEFT JOIN invoice_items ii ON ii.invoice_id = i.id
      ${where}
      GROUP BY i.id
      ORDER BY i.created_at DESC
      LIMIT @limit OFFSET @offset
    `).all(params)

    const total = (db.prepare(`SELECT COUNT(*) as cnt FROM invoices i ${where}`).get(params) as any).cnt
    res.json({ invoices, total, limit: params.limit, offset: params.offset })
  } catch (e: any) {
    res.status(500).json({ error: e.message })
  }
})

invoicesRouter.get('/:id', (req, res) => {
  try {
    const db = getDb()
    const invoice = db.prepare('SELECT * FROM invoices WHERE id = ?').get(req.params.id)
    if (!invoice) return res.status(404).json({ error: 'Invoice not found' })
    const items = db.prepare('SELECT * FROM invoice_items WHERE invoice_id = ? ORDER BY sort_order').all(req.params.id)
    res.json({ ...invoice as object, items })
  } catch (e: any) {
    res.status(500).json({ error: e.message })
  }
})

invoicesRouter.post('/', (req, res) => {
  try {
    const db = getDb()
    const settings = db.prepare('SELECT * FROM settings WHERE id = 1').get() as any
    const body = req.body

    // Generate invoice number
    const prefix = settings.invoice_prefix || 'INV'
    const num = settings.next_invoice_number || 1000
    const invoice_number = body.invoice_number || `${prefix}-${String(num).padStart(5, '0')}`

    const result = db.prepare(`
      INSERT INTO invoices (
        invoice_number, client_id, client_name, client_email, client_company,
        client_address, client_city, client_state, client_zip, client_country,
        status, issue_date, due_date, subtotal, tax_rate, tax_amount,
        discount_type, discount_value, discount_amount, total, amount_paid,
        notes, payment_terms, footer_note, currency, currency_symbol
      ) VALUES (
        @invoice_number, @client_id, @client_name, @client_email, @client_company,
        @client_address, @client_city, @client_state, @client_zip, @client_country,
        @status, @issue_date, @due_date, @subtotal, @tax_rate, @tax_amount,
        @discount_type, @discount_value, @discount_amount, @total, @amount_paid,
        @notes, @payment_terms, @footer_note, @currency, @currency_symbol
      )
    `).run({
      invoice_number,
      client_id: body.client_id || null,
      client_name: body.client_name || '',
      client_email: body.client_email || '',
      client_company: body.client_company || '',
      client_address: body.client_address || '',
      client_city: body.client_city || '',
      client_state: body.client_state || '',
      client_zip: body.client_zip || '',
      client_country: body.client_country || '',
      status: body.status || 'draft',
      issue_date: body.issue_date,
      due_date: body.due_date,
      subtotal: body.subtotal || 0,
      tax_rate: body.tax_rate || 0,
      tax_amount: body.tax_amount || 0,
      discount_type: body.discount_type || 'percent',
      discount_value: body.discount_value || 0,
      discount_amount: body.discount_amount || 0,
      total: body.total || 0,
      amount_paid: body.amount_paid || 0,
      notes: body.notes || '',
      payment_terms: body.payment_terms || settings.payment_terms || 'Net 30',
      footer_note: body.footer_note || settings.payment_instructions || '',
      currency: body.currency || settings.currency || 'USD',
      currency_symbol: body.currency_symbol || settings.currency_symbol || '$',
    })

    const invoiceId = result.lastInsertRowid

    // Insert items
    if (Array.isArray(body.items)) {
      const insertItem = db.prepare(`
        INSERT INTO invoice_items (invoice_id, description, details, quantity, rate, amount, sort_order)
        VALUES (@invoice_id, @description, @details, @quantity, @rate, @amount, @sort_order)
      `)
      body.items.forEach((item: any, idx: number) => {
        insertItem.run({
          invoice_id: invoiceId,
          description: item.description || '',
          details: item.details || '',
          quantity: item.quantity || 1,
          rate: item.rate || 0,
          amount: item.amount || 0,
          sort_order: idx,
        })
      })
    }

    // Increment next invoice number
    db.prepare('UPDATE settings SET next_invoice_number = next_invoice_number + 1 WHERE id = 1').run()

    const invoice = db.prepare('SELECT * FROM invoices WHERE id = ?').get(invoiceId)
    const items = db.prepare('SELECT * FROM invoice_items WHERE invoice_id = ? ORDER BY sort_order').all(invoiceId)
    res.status(201).json({ ...invoice as object, items })
  } catch (e: any) {
    res.status(500).json({ error: e.message })
  }
})

invoicesRouter.put('/:id', (req, res) => {
  try {
    const db = getDb()
    const body = req.body
    const id = req.params.id

    db.prepare(`
      UPDATE invoices SET
        client_id=@client_id, client_name=@client_name, client_email=@client_email,
        client_company=@client_company, client_address=@client_address,
        client_city=@client_city, client_state=@client_state,
        client_zip=@client_zip, client_country=@client_country,
        status=@status, issue_date=@issue_date, due_date=@due_date,
        subtotal=@subtotal, tax_rate=@tax_rate, tax_amount=@tax_amount,
        discount_type=@discount_type, discount_value=@discount_value,
        discount_amount=@discount_amount, total=@total, amount_paid=@amount_paid,
        notes=@notes, payment_terms=@payment_terms, footer_note=@footer_note,
        updated_at=CURRENT_TIMESTAMP
      WHERE id = @id
    `).run({ ...body, id })

    // Replace items
    if (Array.isArray(body.items)) {
      db.prepare('DELETE FROM invoice_items WHERE invoice_id = ?').run(id)
      const insertItem = db.prepare(`
        INSERT INTO invoice_items (invoice_id, description, details, quantity, rate, amount, sort_order)
        VALUES (@invoice_id, @description, @details, @quantity, @rate, @amount, @sort_order)
      `)
      body.items.forEach((item: any, idx: number) => {
        insertItem.run({
          invoice_id: id,
          description: item.description || '',
          details: item.details || '',
          quantity: item.quantity || 1,
          rate: item.rate || 0,
          amount: item.amount || 0,
          sort_order: idx,
        })
      })
    }

    const invoice = db.prepare('SELECT * FROM invoices WHERE id = ?').get(id)
    const items = db.prepare('SELECT * FROM invoice_items WHERE invoice_id = ? ORDER BY sort_order').all(id)
    res.json({ ...invoice as object, items })
  } catch (e: any) {
    res.status(500).json({ error: e.message })
  }
})

invoicesRouter.patch('/:id/status', (req, res) => {
  try {
    const db = getDb()
    const { status, amount_paid } = req.body
    const validStatuses = ['draft', 'sent', 'paid', 'overdue', 'cancelled']
    if (!validStatuses.includes(status)) return res.status(400).json({ error: 'Invalid status' })

    const updates: string[] = ['status = @status', 'updated_at = CURRENT_TIMESTAMP']
    const params: any = { id: req.params.id, status }
    if (amount_paid !== undefined) { updates.push('amount_paid = @amount_paid'); params.amount_paid = amount_paid }

    db.prepare(`UPDATE invoices SET ${updates.join(', ')} WHERE id = @id`).run(params)
    const invoice = db.prepare('SELECT * FROM invoices WHERE id = ?').get(req.params.id)
    res.json(invoice)
  } catch (e: any) {
    res.status(500).json({ error: e.message })
  }
})

invoicesRouter.delete('/:id', (req, res) => {
  try {
    const db = getDb()
    db.prepare('DELETE FROM invoices WHERE id = ?').run(req.params.id)
    res.json({ success: true })
  } catch (e: any) {
    res.status(500).json({ error: e.message })
  }
})
