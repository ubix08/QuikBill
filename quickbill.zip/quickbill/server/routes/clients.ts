import { Router } from 'express'
import { getDb } from '../db.js'

export const clientsRouter = Router()

clientsRouter.get('/', (_req, res) => {
  try {
    const db = getDb()
    const clients = db.prepare(`
      SELECT c.*,
        COUNT(i.id) AS invoice_count,
        COALESCE(SUM(CASE WHEN i.status = 'paid' THEN i.total ELSE 0 END), 0) AS total_paid,
        COALESCE(SUM(CASE WHEN i.status != 'paid' AND i.status != 'draft' THEN i.total ELSE 0 END), 0) AS total_outstanding
      FROM clients c
      LEFT JOIN invoices i ON i.client_id = c.id
      GROUP BY c.id
      ORDER BY c.name ASC
    `).all()
    res.json(clients)
  } catch (e: any) {
    res.status(500).json({ error: e.message })
  }
})

clientsRouter.get('/:id', (req, res) => {
  try {
    const db = getDb()
    const client = db.prepare('SELECT * FROM clients WHERE id = ?').get(req.params.id)
    if (!client) return res.status(404).json({ error: 'Client not found' })
    res.json(client)
  } catch (e: any) {
    res.status(500).json({ error: e.message })
  }
})

clientsRouter.post('/', (req, res) => {
  try {
    const db = getDb()
    const { name, email, phone, company, address, city, state, zip, country, notes } = req.body
    if (!name?.trim()) return res.status(400).json({ error: 'Name is required' })
    const result = db.prepare(`
      INSERT INTO clients (name, email, phone, company, address, city, state, zip, country, notes)
      VALUES (@name, @email, @phone, @company, @address, @city, @state, @zip, @country, @notes)
    `).run({ name, email: email || '', phone: phone || '', company: company || '',
              address: address || '', city: city || '', state: state || '',
              zip: zip || '', country: country || '', notes: notes || '' })
    const client = db.prepare('SELECT * FROM clients WHERE id = ?').get(result.lastInsertRowid)
    res.status(201).json(client)
  } catch (e: any) {
    res.status(500).json({ error: e.message })
  }
})

clientsRouter.put('/:id', (req, res) => {
  try {
    const db = getDb()
    const { name, email, phone, company, address, city, state, zip, country, notes } = req.body
    if (!name?.trim()) return res.status(400).json({ error: 'Name is required' })
    db.prepare(`
      UPDATE clients SET name=@name, email=@email, phone=@phone, company=@company,
        address=@address, city=@city, state=@state, zip=@zip, country=@country,
        notes=@notes, updated_at=CURRENT_TIMESTAMP
      WHERE id = @id
    `).run({ id: req.params.id, name, email: email || '', phone: phone || '',
              company: company || '', address: address || '', city: city || '',
              state: state || '', zip: zip || '', country: country || '', notes: notes || '' })
    const client = db.prepare('SELECT * FROM clients WHERE id = ?').get(req.params.id)
    res.json(client)
  } catch (e: any) {
    res.status(500).json({ error: e.message })
  }
})

clientsRouter.delete('/:id', (req, res) => {
  try {
    const db = getDb()
    db.prepare('DELETE FROM clients WHERE id = ?').run(req.params.id)
    res.json({ success: true })
  } catch (e: any) {
    res.status(500).json({ error: e.message })
  }
})
