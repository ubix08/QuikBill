import { Router } from 'express'
import { getDb } from '../db.js'

export const dashboardRouter = Router()

dashboardRouter.get('/', (_req, res) => {
  try {
    const db = getDb()

    const stats = db.prepare(`
      SELECT
        COUNT(*) AS total_invoices,
        COALESCE(SUM(total), 0) AS total_billed,
        COALESCE(SUM(CASE WHEN status = 'paid' THEN total ELSE 0 END), 0) AS total_paid,
        COALESCE(SUM(CASE WHEN status IN ('sent','overdue') THEN total - amount_paid ELSE 0 END), 0) AS total_outstanding,
        COUNT(CASE WHEN status = 'overdue' THEN 1 END) AS overdue_count,
        COUNT(CASE WHEN status = 'draft' THEN 1 END) AS draft_count,
        COUNT(CASE WHEN status = 'sent' THEN 1 END) AS sent_count,
        COUNT(CASE WHEN status = 'paid' THEN 1 END) AS paid_count
      FROM invoices
    `).get()

    // Monthly revenue last 6 months
    const monthly = db.prepare(`
      SELECT
        strftime('%Y-%m', issue_date) AS month,
        COALESCE(SUM(total), 0) AS billed,
        COALESCE(SUM(CASE WHEN status = 'paid' THEN total ELSE 0 END), 0) AS collected
      FROM invoices
      WHERE issue_date >= date('now', '-6 months')
      GROUP BY month
      ORDER BY month ASC
    `).all()

    // Recent invoices
    const recent = db.prepare(`
      SELECT id, invoice_number, client_name, client_company, status, total, due_date, currency_symbol
      FROM invoices
      ORDER BY created_at DESC
      LIMIT 5
    `).all()

    // Top clients
    const topClients = db.prepare(`
      SELECT
        client_name,
        client_company,
        COUNT(*) AS invoice_count,
        COALESCE(SUM(total), 0) AS total_billed,
        COALESCE(SUM(CASE WHEN status = 'paid' THEN total ELSE 0 END), 0) AS total_paid
      FROM invoices
      GROUP BY client_name
      ORDER BY total_billed DESC
      LIMIT 5
    `).all()

    res.json({ stats, monthly, recent, topClients })
  } catch (e: any) {
    res.status(500).json({ error: e.message })
  }
})
